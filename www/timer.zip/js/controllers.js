angular.module('app.controllers', [])
  
.controller('timerCtrl', function($scope) {

})
 